INSTRUKCJA: Otwórz projekt w Android Studio -> Build APK(s).

YouTube: Wklej URL/ID, Odtwórz (WebView embed) lub Otwórz w aplikacji YouTube.
Uwaga: equalizer może nie wpływać na WebView/YouTube w zależności od urządzenia.
