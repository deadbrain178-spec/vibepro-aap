rootProject.name = "VibePro432HzMasterEQ_Ultimate_MAX_with_icons_v1_5_0_tablet"
include(":app")
